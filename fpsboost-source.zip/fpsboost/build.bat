@echo off
setlocal
cd /d "%~dp0"
title FPS Boost - build

echo.
echo ===== FPS Boost: building the mod jar =====
echo First run downloads JDK 21 and Gradle, about 300 MB. Please wait.
echo.

set "TOOLS=%~dp0.tools"
if not exist "%TOOLS%" mkdir "%TOOLS%"

if exist "%TOOLS%\jdk\bin\java.exe" goto have_jdk
echo [1/3] Downloading JDK 21...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri 'https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse' -OutFile '%TOOLS%\jdk.zip'"
if errorlevel 1 goto fail
powershell -NoProfile -Command "Expand-Archive -Force -Path '%TOOLS%\jdk.zip' -DestinationPath '%TOOLS%\jdk_tmp'"
if errorlevel 1 goto fail
for /d %%D in ("%TOOLS%\jdk_tmp\*") do move "%%D" "%TOOLS%\jdk" >nul
rmdir /s /q "%TOOLS%\jdk_tmp"
del "%TOOLS%\jdk.zip"
:have_jdk

if exist "%TOOLS%\gradle-8.12.1\bin\gradle.bat" goto have_gradle
echo [2/3] Downloading Gradle...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-8.12.1-bin.zip' -OutFile '%TOOLS%\gradle.zip'"
if errorlevel 1 goto fail
powershell -NoProfile -Command "Expand-Archive -Force -Path '%TOOLS%\gradle.zip' -DestinationPath '%TOOLS%'"
if errorlevel 1 goto fail
del "%TOOLS%\gradle.zip"
:have_gradle

set "JAVA_HOME=%TOOLS%\jdk"
set "PATH=%JAVA_HOME%\bin;%PATH%"

echo [3/3] Building the mod...
call "%TOOLS%\gradle-8.12.1\bin\gradle.bat" build --no-daemon
if errorlevel 1 goto fail

copy /y "build\libs\fpsboost-1.0.0.jar" "fpsboost-1.0.0.jar" >nul
echo.
echo ===== DONE =====
echo Your mod: %~dp0fpsboost-1.0.0.jar
echo Put it into .minecraft\mods together with Fabric Loader and Fabric API for 1.21.4.
pause
exit /b 0

:fail
echo.
echo ===== ERROR. Send a screenshot of this window to Claude. =====
pause
exit /b 1
