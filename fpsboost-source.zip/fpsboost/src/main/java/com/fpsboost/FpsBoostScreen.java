package com.fpsboost;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.particle.ParticlesMode;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class FpsBoostScreen extends Screen {
	private static final int[] TARGETS = {60, 90, 120, 144, 165, 240};
	private static final int[] MAX_DISTANCES = {8, 12, 16, 24, 32};
	private static final String[] TAB_NAMES = {"FPS", "Графика", "Вид", "Авто"};

	/** Запоминаем открытую вкладку между открытиями меню. */
	private static int tab = 0;

	private final Screen parent;
	private int slot;
	private int colW;
	private int leftX;
	private int rightX;

	public FpsBoostScreen(Screen parent) {
		super(Text.literal("FPS Boost"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		GameOptions o = this.client.options;
		FpsBoostConfig cfg = FpsBoostConfig.get();
		slot = 0;

		// Вкладки
		int tabW = Math.min(80, (this.width - 20) / TAB_NAMES.length - 4);
		int tabsTotal = TAB_NAMES.length * tabW + (TAB_NAMES.length - 1) * 4;
		int tabX = (this.width - tabsTotal) / 2;
		for (int i = 0; i < TAB_NAMES.length; i++) {
			final int index = i;
			ButtonWidget tabButton = ButtonWidget.builder(Text.literal(TAB_NAMES[i]), b -> {
				tab = index;
				this.clearAndInit();
			}).dimensions(tabX + i * (tabW + 4), 22, tabW, 20).build();
			tabButton.active = (i != tab);
			this.addDrawableChild(tabButton);
		}

		colW = Math.min(150, (this.width - 30) / 2);
		leftX = this.width / 2 - colW - 5;
		rightX = this.width / 2 + 5;

		switch (tab) {
			case 0 -> {
				addOption(o.getMaxFps());
				addOption(o.getEnableVsync());
				addOption(o.getViewDistance());
				addOption(o.getSimulationDistance());
				addOption(o.getEntityDistanceScaling());
				addOption(o.getMipmapLevels());
			}
			case 1 -> {
				addOption(o.getGraphicsMode());
				addOption(o.getParticles());
				addOption(o.getCloudRenderMode());
				addOption(o.getAo());
				addOption(o.getBiomeBlendRadius());
				addOption(o.getEntityShadows());
			}
			case 2 -> {
				addOption(o.getFov());
				addOption(o.getBobView());
				addOption(o.getDistortionEffectScale());
				addOption(o.getFovEffectScale());
			}
			default -> {
				addButton(onOff("Счётчик FPS", cfg.showFps), b -> {
					cfg.showFps = !cfg.showFps;
					b.setMessage(onOff("Счётчик FPS", cfg.showFps));
				});
				addButton(onOff("Авто-дальность", cfg.adaptive), b -> {
					cfg.adaptive = !cfg.adaptive;
					b.setMessage(onOff("Авто-дальность", cfg.adaptive));
				});
				addButton(Text.literal("Целевой FPS: " + cfg.targetFps), b -> {
					cfg.targetFps = next(TARGETS, cfg.targetFps);
					b.setMessage(Text.literal("Целевой FPS: " + cfg.targetFps));
				});
				addButton(Text.literal("Макс. дальность авто: " + cfg.maxDistance), b -> {
					cfg.maxDistance = next(MAX_DISTANCES, cfg.maxDistance);
					b.setMessage(Text.literal("Макс. дальность авто: " + cfg.maxDistance));
				});
			}
		}

		// Пресеты
		String[] presetNames = {"Макс. FPS", "Баланс", "Качество"};
		int pw = Math.min(100, (this.width - 30) / 3);
		int px = this.width / 2 - (pw * 3 + 10) / 2;
		for (int i = 0; i < presetNames.length; i++) {
			final int level = i;
			this.addDrawableChild(ButtonWidget.builder(Text.literal(presetNames[i]), b -> {
				applyPreset(level);
				this.clearAndInit();
			}).dimensions(px + i * (pw + 5), 128, pw, 20).build());
		}

		// Готово
		this.addDrawableChild(ButtonWidget.builder(Text.literal("Готово"), b -> this.close())
				.dimensions(this.width / 2 - 100, Math.max(152, this.height - 28), 200, 20).build());
	}

	private int slotX(int i) {
		return (i % 2 == 0) ? leftX : rightX;
	}

	private int slotY(int i) {
		return 50 + (i / 2) * 24;
	}

	/** Виджет берём у самой игры (SimpleOption) - тот же слайдер/кнопка, что и в ванильных настройках. */
	private void addOption(SimpleOption<?> option) {
		int i = slot++;
		this.addDrawableChild(option.createWidget(this.client.options, slotX(i), slotY(i), colW));
	}

	private void addButton(Text label, ButtonWidget.PressAction action) {
		int i = slot++;
		this.addDrawableChild(ButtonWidget.builder(label, action).dimensions(slotX(i), slotY(i), colW, 20).build());
	}

	private static Text onOff(String name, boolean value) {
		return Text.literal(name + ": " + (value ? "ВКЛ" : "ВЫКЛ"));
	}

	private static int next(int[] values, int current) {
		for (int i = 0; i < values.length; i++) {
			if (values[i] == current) {
				return values[(i + 1) % values.length];
			}
		}
		return values[0];
	}

	private void applyPreset(int level) {
		GameOptions o = this.client.options;
		switch (level) {
			case 0 -> { // Макс. FPS
				o.getMaxFps().setValue(260); // 260 = без ограничения
				o.getEnableVsync().setValue(false);
				o.getViewDistance().setValue(6);
				o.getSimulationDistance().setValue(5);
				o.getEntityDistanceScaling().setValue(0.5);
				o.getMipmapLevels().setValue(0);
				o.getGraphicsMode().setValue(GraphicsMode.FAST);
				o.getParticles().setValue(ParticlesMode.MINIMAL);
				o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
				o.getAo().setValue(false);
				o.getBiomeBlendRadius().setValue(0);
				o.getEntityShadows().setValue(false);
			}
			case 1 -> { // Баланс
				o.getMaxFps().setValue(260);
				o.getEnableVsync().setValue(false);
				o.getViewDistance().setValue(10);
				o.getSimulationDistance().setValue(8);
				o.getEntityDistanceScaling().setValue(0.75);
				o.getMipmapLevels().setValue(2);
				o.getGraphicsMode().setValue(GraphicsMode.FAST);
				o.getParticles().setValue(ParticlesMode.DECREASED);
				o.getCloudRenderMode().setValue(CloudRenderMode.FAST);
				o.getAo().setValue(true);
				o.getBiomeBlendRadius().setValue(2);
				o.getEntityShadows().setValue(false);
			}
			default -> { // Качество
				o.getMaxFps().setValue(144);
				o.getEnableVsync().setValue(false);
				o.getViewDistance().setValue(16);
				o.getSimulationDistance().setValue(12);
				o.getEntityDistanceScaling().setValue(1.0);
				o.getMipmapLevels().setValue(4);
				o.getGraphicsMode().setValue(GraphicsMode.FANCY);
				o.getParticles().setValue(ParticlesMode.ALL);
				o.getCloudRenderMode().setValue(CloudRenderMode.FANCY);
				o.getAo().setValue(true);
				o.getBiomeBlendRadius().setValue(5);
				o.getEntityShadows().setValue(true);
			}
		}
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);

		context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 8, 0xFFFFFFFF);

		String fpsText = this.client.getCurrentFps() + " FPS";
		context.drawTextWithShadow(this.textRenderer, fpsText, this.width - 8 - this.textRenderer.getWidth(fpsText), 8, 0xFF55FF55);

		if (tab == 3) {
			context.drawCenteredTextWithShadow(this.textRenderer,
					Text.literal("Авто-дальность раз в 10 сек. подгоняет дальность"), this.width / 2, 102, 0xFFAAAAAA);
			context.drawCenteredTextWithShadow(this.textRenderer,
					Text.literal("прорисовки под целевой FPS (от 6 до макс.)"), this.width / 2, 112, 0xFFAAAAAA);
		}
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (keyCode == GLFW.GLFW_KEY_P) {
			this.close();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void close() {
		this.client.setScreen(parent);
	}

	@Override
	public void removed() {
		this.client.options.write();
		FpsBoostConfig.save();
	}
}
