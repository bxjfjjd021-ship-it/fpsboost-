package com.fpsboost;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Собственные настройки мода (config/fpsboost.json). Ванильные настройки хранятся в options.txt. */
public final class FpsBoostConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("fpsboost.json");
	private static FpsBoostConfig instance = new FpsBoostConfig();

	public boolean showFps = true;
	public boolean adaptive = false;
	public int targetFps = 120;
	public int maxDistance = 16;

	private FpsBoostConfig() {
	}

	public static FpsBoostConfig get() {
		return instance;
	}

	public static void load() {
		if (Files.exists(FILE)) {
			try (Reader reader = Files.newBufferedReader(FILE)) {
				FpsBoostConfig loaded = GSON.fromJson(reader, FpsBoostConfig.class);
				if (loaded != null) {
					instance = loaded;
				}
			} catch (Exception e) {
				FpsBoostClient.LOGGER.warn("Не удалось прочитать fpsboost.json, беру значения по умолчанию", e);
			}
		}
		save();
	}

	public static void save() {
		try (Writer writer = Files.newBufferedWriter(FILE)) {
			GSON.toJson(instance, writer);
		} catch (Exception e) {
			FpsBoostClient.LOGGER.warn("Не удалось сохранить fpsboost.json", e);
		}
	}
}
