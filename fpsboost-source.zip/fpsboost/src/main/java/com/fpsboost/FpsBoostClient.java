package com.fpsboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FpsBoostClient implements ClientModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("fpsboost");

	private static KeyBinding openMenuKey;
	private boolean conflictChecked = false;
	private int adaptiveTicks = 0;

	@Override
	public void onInitializeClient() {
		FpsBoostConfig.load();

		openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.fpsboost.menu",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_P,
				"key.categories.fpsboost"));

		ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
		HudRenderCallback.EVENT.register(this::onHud);
	}

	private void onTick(MinecraftClient client) {
		if (client.options == null) {
			return;
		}

		if (!conflictChecked) {
			conflictChecked = true;
			resolveKeyConflict(client);
		}

		while (openMenuKey.wasPressed()) {
			if (client.currentScreen == null) {
				client.setScreen(new FpsBoostScreen(null));
			}
		}

		tickAdaptive(client);
	}

	/** В ванили на P висит "Социальные взаимодействия" - снимаем эту клавишу, чтобы P открывал наше меню. */
	private void resolveKeyConflict(MinecraftClient client) {
		GameOptions o = client.options;
		if (o.socialInteractionsKey.getBoundKeyTranslationKey().equals(openMenuKey.getBoundKeyTranslationKey())) {
			o.socialInteractionsKey.setBoundKey(InputUtil.UNKNOWN_KEY);
			KeyBinding.updateKeysByCode();
			o.write();
			LOGGER.info("Клавиша P освобождена от 'Социальных взаимодействий'");
		}
	}

	/** Раз в 10 секунд подстраивает дальность прорисовки под целевой FPS. */
	private void tickAdaptive(MinecraftClient client) {
		FpsBoostConfig cfg = FpsBoostConfig.get();
		if (!cfg.adaptive || client.world == null || client.isPaused()) {
			adaptiveTicks = 0;
			return;
		}
		if (++adaptiveTicks < 200) {
			return;
		}
		adaptiveTicks = 0;

		int fps = client.getCurrentFps();
		SimpleOption<Integer> view = client.options.getViewDistance();
		int dist = view.getValue();

		if (fps < cfg.targetFps * 0.85 && dist > 6) {
			view.setValue(dist - 1);
		} else if (fps > cfg.targetFps * 1.4 && dist < cfg.maxDistance) {
			view.setValue(dist + 1);
		}
	}

	private void onHud(DrawContext context, RenderTickCounter tickCounter) {
		FpsBoostConfig cfg = FpsBoostConfig.get();
		MinecraftClient client = MinecraftClient.getInstance();
		if (!cfg.showFps || client.options.hudHidden) {
			return;
		}
		int fps = client.getCurrentFps();
		int color = fps >= 100 ? 0xFF55FF55 : (fps >= 60 ? 0xFFFFFF55 : 0xFFFF5555);
		context.drawTextWithShadow(client.textRenderer, fps + " FPS", 4, 4, color);
	}
}
